To run the program follow the below steps
> javac Node.java 
> javac Solution.java 
> java Solution

enter input in the console. 

